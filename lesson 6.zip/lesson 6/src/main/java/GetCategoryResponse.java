import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Data

public class GetCategoryResponse {
    @JsonProperty("id")
    private Integer id;
    @JsonProperty("title")
    private String title;
    @JsonProperty("products")
    private List<Product> products = new ArrayList<>();

    public static class ConfigUtils {
        blic class ConfigUtils {
            Properties prop = new Properties();
            private static InputStream configFile;
            static {
    © geekbrains.ru 7
                try {
                    configFile = new
                            FileInputStream("src/test/resources/application.properties");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            @SneakyThrows
            public String getBaseUrl() {
                prop.load(configFile);
                return prop.getProperty("url");
            }
        }

    }
}
