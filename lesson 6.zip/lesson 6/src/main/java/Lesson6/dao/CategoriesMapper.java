package Lesson6.dao;

public class CategoriesMapper {
}
