import static org.junit.jupiter.api.Assertions.*;

class CategoryServiceTest {
    static CategoryService categoryService;
    @BeforeAll
    static void beforeAll() {
        categoryService =
                RetrofitUtils.getRetrofit().create(CategoryService.class);
    }


}